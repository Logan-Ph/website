// Define dice images
const diceImages = [
  'assets/dice-red-1.png',
  'assets/dice-red-2.png',
  'assets/dice-red-3.png',
  'assets/dice-red-4.png',
  'assets/dice-red-5.png',
  'assets/dice-red-6.png',
];

// Get elements from the DOM
const betSelect = document.getElementById('bet');
const rollButton = document.getElementById('roll');
const dicesDiv = document.getElementById('dices');
const resultDiv = document.getElementById('result');

// ADD YOUR CODE HERE
// Add event listener to roll button


function rollDices() {
  // ADD YOUR CODE HERE

  // Roll three dices (random numbers)

  // Display dices on the screen


  // Calculate sum of dices


  // Determine the result based on the sum and the user's bet


  // Display the result and the sum on the screen

  // Play the sound effect of spinning

}